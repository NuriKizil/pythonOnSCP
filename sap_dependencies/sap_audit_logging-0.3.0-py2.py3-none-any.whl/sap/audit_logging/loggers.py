''' Loggers '''
import logging
import requests

AUDIT_SERVICE_URL_PATH = 'audit-log/v2'
AUDIT_LOG_CLIENT_LOGGER = 'py-audit-logger-client'

class ConsoleLogger(object): # pylint: disable=too-few-public-methods
    ''' ConsoleLogger '''
    @staticmethod
    def log(message, endpoint):
        ''' Print to standart out '''
        print('{0}: {1}'.format(endpoint, message)) # pylint: disable=superfluous-parens

class HttpLogger(object): # pylint: disable=too-few-public-methods
    ''' HttpLogger '''

    def __init__(self, credentials):
        self._user = credentials['user']
        self._password = credentials['password']
        self._url = '{0}/{1}'.format(credentials['url'],
                                     AUDIT_SERVICE_URL_PATH)
        logging.basicConfig()
        self._logger = logging.getLogger(__name__)

    def log(self, message, endpoint):
        ''' Send message to service '''
        url = self._url + endpoint
        self._logger.debug('>>> URL: %s, message:%s', url, message)
        response = requests.post(
            url, json=message,
            auth=(self._user, self._password))
        _check_status_code(response, url)

def _check_status_code(response, url):
    if response.status_code not in [200, 201, 204]:
        raise RuntimeError(
            'Unexpected status code {0} while requesting {1}. Response from server: {2}'
            .format(response.status_code, url, response.text)
        )
