'''
Audit log client
'''

from sap.audit_logging.__version__ import __version__
from sap.audit_logging.audit_logger import AuditLogger
