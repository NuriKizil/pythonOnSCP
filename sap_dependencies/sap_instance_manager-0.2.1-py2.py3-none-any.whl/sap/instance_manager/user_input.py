''' User input validation utilities '''

import copy
from past.builtins import basestring
from sap.instance_manager.constants import MANDATORY_OPTIONS, DEFAULT_OPTIONS


def process_main_options(options):
    ''' validates and sets default options given to instance_manager.create '''
    opts = copy.copy(options)
    _validate_main_options(opts)
    _set_main_options_defaults(opts)
    return opts


def process_tenant(tenant):
    ''' validates tenant '''
    if not isinstance(tenant, basestring):
        raise ValueError('Tenant should be a string')
    tenant = tenant.strip()
    if not tenant:
        raise ValueError('Tenant cannot be an empty string')

    return tenant

def _validate_main_options(options):
    if not isinstance(options, dict):
        raise ValueError('Options should be an object')

    for option in MANDATORY_OPTIONS:
        if not options.get(option) or not isinstance(options[option], basestring):
            raise ValueError(
                'Property "{0}" should be a non-empty string'.format(option))

    for prop in ['polling_interval_millis']:
        _validate_non_negative_integer(options, prop)

    for prop in ['polling_timeout_seconds', 'cache_max_items', 'cache_item_expire_seconds']:
        _validate_positive_integer(options, prop)


def _set_main_options_defaults(options):
    _set_default_value(options, 'cache_max_items')
    _set_default_value(options, 'cache_item_expire_seconds')
    _set_default_value(options, 'polling_interval_millis')
    _set_default_value(options, 'polling_timeout_seconds')


def _validate_non_negative_integer(options, prop):
    if prop in options:
        value = int(options[prop])
        if value < 0:
            error_str = 'Property "{0}" should be a non-negative integer (if provided)'.format(
                prop)
            raise ValueError(error_str)


def _validate_positive_integer(options, prop):
    if prop in options:
        value = int(options[prop])
        if value <= 0:
            error_str = 'Property "{0}" should be a positive integer (if provided)'.format(
                prop)
            raise ValueError(error_str)


def _set_default_value(dictionary, key):
    if key not in dictionary or dictionary[key] is None:
        dictionary[key] = DEFAULT_OPTIONS[key]
